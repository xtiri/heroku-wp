<?php

include_once EDGE_CORE_CPT_PATH.'/portfolio/portfolio-register.php';
include_once EDGE_CORE_CPT_PATH.'/portfolio/helper-functions.php';
include_once EDGE_CORE_CPT_PATH.'/portfolio/shortcodes/shortcodes-functions.php';