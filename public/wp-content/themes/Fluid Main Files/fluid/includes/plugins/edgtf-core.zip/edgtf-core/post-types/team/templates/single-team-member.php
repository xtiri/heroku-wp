<?php

get_header();

fluid_edge_get_title();

edgtf_core_get_single_team();

get_footer();