<?php

get_header();

fluid_edge_get_title(false, 'portfolio_single');

edgtf_core_get_single_portfolio();

get_footer();