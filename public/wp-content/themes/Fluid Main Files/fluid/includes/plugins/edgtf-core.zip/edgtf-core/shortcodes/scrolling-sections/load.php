<?php

include_once EDGE_CORE_SHORTCODES_PATH.'/scrolling-sections/functions.php';
include_once EDGE_CORE_SHORTCODES_PATH.'/scrolling-sections/scrolling-sections.php';
include_once EDGE_CORE_SHORTCODES_PATH.'/scrolling-sections/scrolling-sections-item.php';