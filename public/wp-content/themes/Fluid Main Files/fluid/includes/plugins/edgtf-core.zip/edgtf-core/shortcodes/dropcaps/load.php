<?php

include_once EDGE_CORE_SHORTCODES_PATH.'/dropcaps/functions.php';
include_once EDGE_CORE_SHORTCODES_PATH.'/dropcaps/dropcaps.php';