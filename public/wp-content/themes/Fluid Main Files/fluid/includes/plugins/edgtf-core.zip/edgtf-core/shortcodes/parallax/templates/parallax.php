<div class="edgtf-parallax-holder <?php echo esc_attr($holder_class); ?>" <?php echo fluid_edge_get_inline_attrs($holder_data); ?> <?php echo fluid_edge_get_inline_style($holder_style); ?>>
	<div class="edgtf-parallax-inner">
		<?php echo do_shortcode($content); ?>
	</div>
</div>
