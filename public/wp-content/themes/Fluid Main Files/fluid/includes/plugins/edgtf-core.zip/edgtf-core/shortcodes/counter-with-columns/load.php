<?php

include_once EDGE_CORE_SHORTCODES_PATH.'/counter-with-columns/functions.php';
include_once EDGE_CORE_SHORTCODES_PATH.'/counter-with-columns/counter-holder.php';